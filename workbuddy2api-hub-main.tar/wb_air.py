# -*- coding: utf-8 -*-
"""Air 出口：ps.air-outer.com（Agent Router）的客户端与协议翻译。

上游是一个 OpenAI 兼容中转，但它只提供 **Responses API**（`/v1/responses`），
`/v1/chat/completions` 对它的模型一律回 400；而且它按客户端指纹放行，不认识的
User-Agent 会被直接拒成 401 `unauthorized client detected`。所以这个出口要做两件事：

- **去程**：把标准 Chat Completions 请求体翻译成 Responses 请求体
  （`messages` → `input`，system/developer → `instructions`，工具定义摊平），
  并带上放行所需的 UA。
- **回程**：把 Responses 的事件流翻译回标准 OpenAI chunk
  （`response.output_text.delta` → `delta.content`，
  `response.function_call_arguments.delta` → `delta.tool_calls[].function.arguments`），
  末尾补一帧 usage 与 `data: [DONE]`。

回程契约与 `wb_codearts.CodeArtsStream` 一致：wb-hub 的 `_chat_stream_response`
与 `aggregate_stream` 只认标准 chunk（`choices[].delta` / `finish_reason` /
`usage`），不认 Responses 的事件名。

与 CodeArts 出口的区别：这里没有账号池、没有 OAuth、没有签到，只有一份
「Base URL + API Key」配置，默认关闭。`model_entries()` 缓存一小时，拉不到时
回退到种子清单，避免一次上游抖动就让出口从面板/`/v1/models` 里消失。
"""

import json
import socket
import threading
import time
import urllib.error
import urllib.request

import wb_settings

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://ps.air-outer.com"
#: 上游只放行它认识的客户端；这个值实测可用（`codex_cli_rs/0.21.0` 亦可）。
DEFAULT_USER_AGENT = "claude-cli/2.0.1 (external, cli)"

EP_MODELS = "/v1/models"
EP_RESPONSES = "/v1/responses"

#: 上游错误体的读取上限；中转的错误体都是几百字节的小 JSON。
ERROR_BODY_MAX = 1024 * 1024

DEFAULTS = {
    "enabled": False,
    "base_url": DEFAULT_BASE_URL,
    "api_key": "",
    "user_agent": DEFAULT_USER_AGENT,
    "timeout_seconds": 60.0,
    "stream_timeout_seconds": 600.0,
    "models_ttl_seconds": 3600.0,
}

#: 模型目录冷启动种子：`/v1/models` 拉不到时用它，出口才不会凭空消失。
SEED_MODELS = ("gpt-5.6-sol", "gpt-6-astra", "gpt-6.1-sol")


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class AirError(Exception):
    status = 502

    def __init__(self, message, status=None, code=None):
        Exception.__init__(self, message)
        if status is not None:
            self.status = status
        self.code = code
        self.message = message


class AirBadRequest(AirError):
    status = 400


class AirAuthError(AirError):
    status = 502


class AirUpstreamError(AirError):
    status = 502


class AirUnavailable(AirError):
    status = 502


# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------

def _positive_float(value, default, low, high):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if number != number:  # NaN
        return default
    return max(low, min(high, number))


def _clean_base_url(value):
    text = str(value or "").strip()
    if not text:
        return DEFAULT_BASE_URL
    if not text.startswith(("http://", "https://")):
        text = "https://" + text
    return text.rstrip("/")


def load_config(accounts_dir):
    """读取并收敛 Air 配置；非法值回落默认，不阻塞网关启动。"""
    raw = wb_settings.load(accounts_dir).get("air")
    if not isinstance(raw, dict):
        raw = {}
    return {
        "enabled": raw.get("enabled") is True,
        "base_url": _clean_base_url(raw.get("base_url")),
        "api_key": str(raw.get("api_key") or "").strip(),
        "user_agent": (str(raw.get("user_agent") or "").strip()
                       or DEFAULT_USER_AGENT),
        "timeout_seconds": _positive_float(
            raw.get("timeout_seconds"), DEFAULTS["timeout_seconds"], 1.0, 600.0),
        "stream_timeout_seconds": _positive_float(
            raw.get("stream_timeout_seconds"),
            DEFAULTS["stream_timeout_seconds"], 1.0, 3600.0),
        "models_ttl_seconds": _positive_float(
            raw.get("models_ttl_seconds"), DEFAULTS["models_ttl_seconds"],
            60.0, 86400.0),
        "accounts_dir": accounts_dir,
    }


def save_config(accounts_dir, patch):
    """保存配置；返回完整配置。非法值抛 ValueError。"""
    if not isinstance(patch, dict):
        raise ValueError("air settings must be an object")
    current = load_config(accounts_dir)
    merged = dict(current)
    for key in DEFAULTS:
        if key in patch:
            merged[key] = patch[key]
    merged["enabled"] = merged.get("enabled") is True
    api_key = str(merged.get("api_key") or "").strip()
    if api_key:
        merged["api_key"] = api_key
    merged["base_url"] = _clean_base_url(merged.get("base_url"))
    merged["user_agent"] = (str(merged.get("user_agent") or "").strip()
                            or DEFAULT_USER_AGENT)
    merged["timeout_seconds"] = _positive_float(
        merged.get("timeout_seconds"), DEFAULTS["timeout_seconds"], 1.0, 600.0)
    merged["stream_timeout_seconds"] = _positive_float(
        merged.get("stream_timeout_seconds"),
        DEFAULTS["stream_timeout_seconds"], 1.0, 3600.0)
    merged["models_ttl_seconds"] = _positive_float(
        merged.get("models_ttl_seconds"), DEFAULTS["models_ttl_seconds"],
        60.0, 86400.0)
    data = wb_settings.load(accounts_dir)
    data["air"] = {k: merged[k] for k in DEFAULTS}
    wb_settings.save(accounts_dir, data)
    invalidate_models()
    return load_config(accounts_dir)


def configured_config(config):
    """出口可用 = 已启用且填了 Key。两者缺一都当成未配置。"""
    return bool(config.get("enabled")) and bool(str(config.get("api_key") or "").strip())


def configured(accounts_dir):
    return configured_config(load_config(accounts_dir))


def masked_config(accounts_dir):
    """面板用的配置快照：Key 只留末四位，其余原样返回。"""
    cfg = load_config(accounts_dir)
    key = cfg.get("api_key") or ""
    out = {k: v for k, v in cfg.items() if k not in ("accounts_dir", "api_key")}
    out["api_key_masked"] = ("…" + key[-4:]) if len(key) > 4 else ("…" if key else "")
    out["configured"] = configured_config(cfg)
    return out


# ---------------------------------------------------------------------------
# 出站
# ---------------------------------------------------------------------------

_DIRECT_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _headers(config, stream=True):
    headers = {
        "Authorization": "Bearer " + (config.get("api_key") or ""),
        "Content-Type": "application/json",
        # 上游按客户端指纹放行：这个 UA 不是可选项。
        "User-Agent": config.get("user_agent") or DEFAULT_USER_AGENT,
        "Accept": "text/event-stream" if stream else "application/json",
        "Accept-Encoding": "identity",
    }
    return headers


def _error_text(raw):
    try:
        parsed = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return raw.decode("utf-8", "replace")[:500]
    if isinstance(parsed, dict):
        err = parsed.get("error")
        if isinstance(err, dict):
            message = err.get("message")
            if isinstance(message, str) and message:
                return message[:500]
        if isinstance(err, str) and err:
            return err[:500]
        for key in ("message", "detail", "error_description"):
            value = parsed.get(key)
            if isinstance(value, str) and value:
                return value[:500]
    return raw.decode("utf-8", "replace")[:500]


def _raise_http_error(code, raw):
    message = _error_text(raw)
    if code in (401, 403):
        raise AirAuthError("Air 上游拒绝了密钥：%s" % message, status=code)
    if code == 400:
        raise AirBadRequest(message, status=code)
    if code == 404:
        raise AirUpstreamError(
            "Air 上游没有这个接口（请确认 Base URL 只填到域名，路径由网关拼）：%s"
            % message, status=code)
    if code == 429:
        raise AirUpstreamError(message, status=code, code="429")
    raise AirUpstreamError("Air 上游返回 HTTP %s：%s" % (code, message),
                           status=code)


def _open(req, timeout):
    try:
        return _DIRECT_OPENER.open(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        try:
            raw = exc.read(ERROR_BODY_MAX)
        except Exception:
            raw = b""
        _raise_http_error(exc.code, raw)
    except (urllib.error.URLError, socket.timeout, TimeoutError,
            ConnectionError, OSError) as exc:
        reason = getattr(exc, "reason", None) or exc
        raise AirUnavailable("连不上 Air 上游：%s - 请检查本机网络。" % reason)


# ---------------------------------------------------------------------------
# 模型目录
# ---------------------------------------------------------------------------

_CATALOG_LOCK = threading.RLock()
_CATALOG = {"key": None, "at": 0.0, "entries": None, "error": None,
            "live": False}


def _catalog_key(config):
    return (config.get("base_url"), config.get("api_key"),
            config.get("user_agent"))


def invalidate_models():
    with _CATALOG_LOCK:
        _CATALOG["key"] = None
        _CATALOG["at"] = 0.0
        _CATALOG["entries"] = None
        _CATALOG["error"] = None
        _CATALOG["live"] = False


def _entry(model_id):
    return {"id": model_id, "object": "model", "created": 0,
            "owned_by": "air-outer"}


def _seed_entries():
    return [_entry(m) for m in SEED_MODELS]


def _fetch_models(config):
    url = config["base_url"] + EP_MODELS
    req = urllib.request.Request(url, headers=_headers(config, stream=False),
                                 method="GET")
    resp = _open(req, timeout=float(config.get("timeout_seconds") or 60.0))
    try:
        raw = resp.read(ERROR_BODY_MAX)
    finally:
        try:
            resp.close()
        except Exception:
            pass
    try:
        parsed = json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        raise AirUpstreamError("Air 上游返回了无法解析的模型列表")
    items = parsed.get("data") if isinstance(parsed, dict) else None
    if not isinstance(items, list):
        raise AirUpstreamError("Air 上游的模型列表格式不认识")
    entries = []
    for item in items:
        if not isinstance(item, dict):
            continue
        model_id = str(item.get("id") or "").strip()
        if model_id:
            entries.append(_entry(model_id))
    return entries


def model_entries(config, force=False):
    """上游模型目录；命中缓存直接返回，拉取失败回退上一轮或种子清单。"""
    if not configured_config(config):
        raise AirBadRequest("Air 出口未启用：请到设置页打开「启用 Air 出口」并填写 API Key。")
    key = _catalog_key(config)
    ttl = float(config.get("models_ttl_seconds") or DEFAULTS["models_ttl_seconds"])
    now = time.time()
    with _CATALOG_LOCK:
        fresh = (not force and _CATALOG["key"] == key
                 and _CATALOG["entries"] is not None
                 and (now - _CATALOG["at"]) < ttl)
        if fresh:
            return list(_CATALOG["entries"])
        previous = _CATALOG["entries"] if _CATALOG["key"] == key else None
    try:
        entries = _fetch_models(config)
        error = None
    except AirError as exc:
        entries = previous if previous else _seed_entries()
        error = str(exc)
    with _CATALOG_LOCK:
        _CATALOG["key"] = key
        _CATALOG["at"] = time.time()
        _CATALOG["entries"] = list(entries)
        _CATALOG["error"] = error
        _CATALOG["live"] = error is None
    return list(entries)


def models_meta(config):
    with _CATALOG_LOCK:
        error = _CATALOG["error"]
        fetched_at = _CATALOG["at"] or None
        live = bool(_CATALOG["live"])
    return {
        "base_url": config.get("base_url"),
        "source": "live" if live else ("cache" if error else "seed"),
        "fetched_at": fetched_at,
        "error": error,
    }


def health(config, force=False):
    """一次真实的上游探活：成功返回模型数，失败把原因带回去。"""
    if not configured_config(config):
        return {"ok": False, "models": 0,
                "error": "Air 出口未启用：请到设置页打开「启用 Air 出口」并填写 API Key。"}
    try:
        entries = model_entries(config, force=force)
    except AirError as exc:
        return {"ok": False, "models": 0, "error": str(exc)}
    return {"ok": True, "models": len(entries), "error": None,
            "base_url": config.get("base_url")}


# ---------------------------------------------------------------------------
# 请求体翻译：Chat Completions -> Responses
# ---------------------------------------------------------------------------

#: 客户端思考档位 -> Responses 的 reasoning.effort。上游对未知档位回 400，
#: 所以这里只翻译它认识的三个值，其余原样透传前先归一。
_EFFORT_MAP = {
    "minimal": "low",
    "low": "low",
    "medium": "medium",
    "high": "high",
    "xhigh": "high",
    "max": "high",
}


def _flatten_text(content):
    """把 content 折成纯文本：字符串原样，分段列表只取 text 段。"""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict):
                if part.get("type") in (None, "text", "input_text", "output_text"):
                    text = part.get("text")
                    if isinstance(text, str):
                        parts.append(text)
        return "".join(parts)
    return str(content)


def _convert_tools(tools):
    """Chat Completions 的 `{type:function, function:{...}}` -> Responses 的摊平形式。"""
    out = []
    for tool in tools or []:
        if not isinstance(tool, dict):
            continue
        if tool.get("type") not in (None, "function"):
            # 上游支持的内置工具（web_search 等）不在这个出口的承诺范围内。
            continue
        fn = tool.get("function") if isinstance(tool.get("function"), dict) else tool
        name = str(fn.get("name") or "").strip()
        if not name:
            continue
        entry = {"type": "function", "name": name}
        if fn.get("description"):
            entry["description"] = fn["description"]
        if fn.get("parameters") is not None:
            entry["parameters"] = fn["parameters"]
        out.append(entry)
    return out


def _convert_tool_choice(choice):
    if isinstance(choice, str):
        return choice if choice in ("auto", "none", "required") else None
    if isinstance(choice, dict):
        fn = choice.get("function") if isinstance(choice.get("function"), dict) else choice
        name = str(fn.get("name") or "").strip()
        if name:
            return {"type": "function", "name": name}
    return None


def build_chat_body(payload):
    """Chat Completions 请求体 -> Responses 请求体（始终流式，由回程聚合）。"""
    instructions = []
    items = []
    for msg in payload.get("messages") or []:
        if not isinstance(msg, dict):
            continue
        role = str(msg.get("role") or "").lower()
        content = msg.get("content")
        if role in ("system", "developer"):
            text = _flatten_text(content)
            if text:
                instructions.append(text)
            continue
        if role == "assistant":
            text = _flatten_text(content)
            if text:
                items.append({"role": "assistant", "content": text})
            for call in msg.get("tool_calls") or []:
                if not isinstance(call, dict):
                    continue
                fn = call.get("function") if isinstance(call.get("function"), dict) else {}
                items.append({
                    "type": "function_call",
                    "call_id": str(call.get("id") or ""),
                    "name": str(fn.get("name") or ""),
                    "arguments": str(fn.get("arguments") or "{}"),
                })
            continue
        if role == "tool":
            items.append({
                "type": "function_call_output",
                "call_id": str(msg.get("tool_call_id") or ""),
                "output": _flatten_text(content),
            })
            continue
        items.append({"role": "user", "content": _flatten_text(content)})

    body = {
        "model": payload.get("model") or "",
        "input": items,
        "stream": True,
        # 上游默认 store=true（会话里能查到历史）；这个出口是无状态转发，
        # 不留上游会话，省得同一台设备的历史互相串。
        "store": False,
    }
    if instructions:
        body["instructions"] = "\n\n".join(instructions)
    max_tokens = payload.get("max_completion_tokens")
    if max_tokens is None:
        max_tokens = payload.get("max_tokens")
    if isinstance(max_tokens, int) and max_tokens > 0:
        body["max_output_tokens"] = max_tokens
    for key in ("temperature", "top_p"):
        value = payload.get(key)
        if isinstance(value, (int, float)):
            body[key] = value
    effort = payload.get("reasoning_effort")
    if isinstance(effort, str) and effort.strip().lower() in _EFFORT_MAP:
        body["reasoning"] = {"effort": _EFFORT_MAP[effort.strip().lower()]}
    tools = _convert_tools(payload.get("tools"))
    if tools:
        body["tools"] = tools
        choice = _convert_tool_choice(payload.get("tool_choice"))
        if choice is not None:
            body["tool_choice"] = choice
    return body


# ---------------------------------------------------------------------------
# 回程翻译：Responses 事件 -> OpenAI chunk
# ---------------------------------------------------------------------------

def _openai_usage(usage):
    """Responses 的 usage -> Chat Completions 的 usage。

    上游给的是 input_tokens / output_tokens，下游 `record_usage` 与
    `chat_usage_chunk` 认的是 prompt_tokens / completion_tokens；不换算就记成 0。
    """
    if not isinstance(usage, dict):
        return None
    prompt = int(usage.get("input_tokens") or 0)
    completion = int(usage.get("output_tokens") or 0)
    total = int(usage.get("total_tokens") or (prompt + completion))
    details = usage.get("output_tokens_details") or {}
    prompt_details = usage.get("input_tokens_details") or {}
    return {
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": total,
        "prompt_tokens_details": {
            "cached_tokens": int(prompt_details.get("cached_tokens") or 0),
        },
        "completion_tokens_details": {
            "reasoning_tokens": int(details.get("reasoning_tokens") or 0),
        },
    }


class AirAccount(object):
    """Air 出口没有账号池，但回程处理器会读 uid / 出口 URL 做用量归属。"""

    def __init__(self, config):
        self.uid = "air"
        self.nickname = "Air 出口"
        self.realm = "air"
        self.proxy = ""
        self.base_url = config.get("base_url") or DEFAULT_BASE_URL
        self.chat_path = EP_RESPONSES

    def chat_base_url(self):
        return self.base_url


class AirStream(object):
    """把 Responses 事件流包成 wb-hub 回程处理器能吃的行迭代器。

    产出的是标准 OpenAI chunk（`data: {...}\\n\\n`），末尾一帧 usage 与
    `data: [DONE]`——与 `wb_codearts.CodeArtsStream` 的契约一致。
    """

    def __init__(self, raw, model):
        self.raw = raw
        self.model = model
        self._wb_billed_model = model
        self._created = int(time.time())
        self._id = "chatcmpl-air"
        self._pending_chunks = []
        self._event = None
        self._done = False
        self._finish_sent = False
        self._saw_tool_call = False
        self._tool_index = {}
        self._next_tool = 0
        self._usage = None

    # -- 生命周期 ---------------------------------------------------------
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def preflight(self):
        """读到第一个可下发的事件，把嵌在 200 里的业务错误提前抛出来。

        写响应头之前必须先知道上游是真在出内容还是回了错误事件；读到的第一帧
        内容存进 `_pending_chunks`，由 `__iter__` 先吐出去，不丢字。
        """
        while True:
            event, payload = self._read_event()
            if event is None and payload is None:
                return
            chunk = self._apply(payload)
            if chunk:
                self._pending_chunks.append(chunk)
                return

    def close(self):
        try:
            self.raw.close()
        except Exception:
            pass

    # -- 解析 -------------------------------------------------------------
    def _readline(self):
        try:
            return self.raw.readline()
        except (socket.timeout, TimeoutError):
            raise AirUpstreamError("Air 上游流式读取超时")
        except (ConnectionError, OSError) as exc:
            raise AirUpstreamError("Air 上游流式连接中断：%s" % exc)

    def _read_event(self):
        """读一个 SSE 事件，返回 (event_name, payload)；流结束时返回 (None, None)。"""
        data_lines = []
        while True:
            line = self._readline()
            if not line:
                if data_lines:
                    break
                return None, None
            stripped = line.strip()
            if not stripped:
                if data_lines:
                    break
                continue
            if stripped.startswith(b"event:"):
                self._event = stripped[6:].strip().decode("utf-8", "replace")
                continue
            if stripped.startswith(b"data:"):
                data_lines.append(stripped[5:].strip())
                continue
            if stripped.startswith(b":"):
                continue
        raw = b"\n".join(data_lines)
        if not raw:
            return self._event, None
        text = raw.decode("utf-8", "replace")
        if text.strip() == "[DONE]":
            return None, None
        try:
            payload = json.loads(text)
        except Exception:
            return self._event, None
        return (self._event, payload) if isinstance(payload, dict) else (self._event, None)

    # -- 事件 -> chunk ----------------------------------------------------
    def _chunk(self, delta, finish=None):
        payload = {
            "id": self._id,
            "object": "chat.completion.chunk",
            "created": self._created,
            "model": self.model,
            "choices": [{"index": 0, "delta": delta or {},
                         "finish_reason": finish}],
        }
        return ("data: " + json.dumps(payload, ensure_ascii=False) + "\n\n").encode("utf-8")

    def _apply(self, payload):
        """消化一个事件；需要回给客户端的 chunk 作为返回值。"""
        if not isinstance(payload, dict):
            return None
        kind = payload.get("type") or self._event
        if kind == "response.output_text.delta":
            delta = payload.get("delta")
            return self._chunk({"content": delta}) if delta else None
        if kind in ("response.reasoning_summary_text.delta",
                    "response.reasoning_text.delta"):
            delta = payload.get("delta")
            return self._chunk({"reasoning_content": delta}) if delta else None
        if kind == "response.output_item.added":
            item = payload.get("item") or {}
            if item.get("type") == "function_call":
                index = payload.get("output_index")
                if index not in self._tool_index:
                    self._tool_index[index] = self._next_tool
                    self._next_tool += 1
                slot = self._tool_index[index]
                self._saw_tool_call = True
                return self._chunk({"tool_calls": [{
                    "index": slot,
                    "id": str(item.get("call_id") or item.get("id") or ""),
                    "type": "function",
                    "function": {"name": str(item.get("name") or ""),
                                 "arguments": ""},
                }]})
            return None
        if kind == "response.function_call_arguments.delta":
            delta = payload.get("delta")
            if not delta:
                return None
            slot = self._tool_index.get(payload.get("output_index"), 0)
            return self._chunk({"tool_calls": [{
                "index": slot,
                "function": {"arguments": delta},
            }]})
        if kind in ("response.completed", "response.incomplete"):
            response = payload.get("response") or {}
            usage = _openai_usage(response.get("usage"))
            if usage:
                self._usage = usage
            if response.get("model"):
                self.model = response["model"]
            self._done = True
            return None
        if kind == "response.failed":
            response = payload.get("response") or {}
            error = response.get("error") or {}
            raise AirUpstreamError(str(error.get("message")
                                       or "Air 上游返回 response.failed"))
        if kind == "error":
            raise AirUpstreamError(str(payload.get("message")
                                       or payload.get("error") or "Air 上游返回错误事件"))
        return None

    def __iter__(self):
        while self._pending_chunks:
            yield self._pending_chunks.pop(0)
        while not self._done:
            event, payload = self._read_event()
            if event is None and payload is None:
                break
            chunk = self._apply(payload)
            if chunk:
                yield chunk
        if not self._finish_sent:
            self._finish_sent = True
            yield self._chunk({}, "tool_calls" if self._saw_tool_call else "stop")
        if self._usage:
            yield ("data: " + json.dumps({
                "id": self._id,
                "object": "chat.completion.chunk",
                "created": self._created,
                "model": self.model,
                "choices": [],
                "usage": self._usage,
            }, ensure_ascii=False) + "\n\n").encode("utf-8")
        yield b"data: [DONE]\n\n"


# ---------------------------------------------------------------------------
# 打开上游
# ---------------------------------------------------------------------------

def open_chat(config, body):
    """把一次 Chat Completions 请求发到上游 Responses；返回 (stream, account, model)。"""
    if not configured_config(config):
        raise AirBadRequest(
            "Air 出口未启用：请到设置页打开「启用 Air 出口」并填写 API Key。")
    model = str(body.get("model") or "").strip()
    if not model:
        raise AirBadRequest("请求缺少 model")
    upstream_body = build_chat_body(body)
    raw = json.dumps(upstream_body, ensure_ascii=False).encode("utf-8")
    url = config["base_url"] + EP_RESPONSES
    req = urllib.request.Request(url, data=raw, headers=_headers(config, stream=True),
                                 method="POST")
    timeout = float(config.get("stream_timeout_seconds")
                    or DEFAULTS["stream_timeout_seconds"])
    resp = _open(req, timeout)
    stream = AirStream(resp, model)
    try:
        stream.preflight()
    except Exception:
        stream.close()
        raise
    return stream, AirAccount(config), model
