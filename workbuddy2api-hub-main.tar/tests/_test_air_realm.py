"""Air 出口（ps.air-outer -> Responses API）：翻译、路由与门禁。

假上游 + 真 hub handler，不碰外网、不碰 WorkBuddy 账号池。上游只认两件事：
`/v1/responses`（本出口里 chat/completions 由网关翻译过来）与它认识的
User-Agent，所以这里两件都断言。
"""
import json
import os
import sys
import threading
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

from _isolated_dirs import isolated_data_dirs  # noqa: E402

_TMP = isolated_data_dirs("wb-air-realm-")
ACCOUNTS = os.environ["ACCOUNTS_DIR"]
USAGE = os.environ["WB_PROXY_USAGE_DIR"]

import wb_air  # noqa: E402
import wb_proxy  # noqa: E402
import wb_settings  # noqa: E402

PASS = FAIL = 0


def check(label, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  [PASS] " + label)
    else:
        FAIL += 1
        print("  [FAIL] " + label + ("  " + str(extra) if extra else ""))


# ---------------------------------------------------------------------------
# 假上游
# ---------------------------------------------------------------------------

TEXT_EVENTS = [
    ("response.output_text.delta",
     {"type": "response.output_text.delta", "output_index": 1, "delta": "你好"}),
    ("response.output_text.delta",
     {"type": "response.output_text.delta", "output_index": 1, "delta": "！"}),
]

TOOL_EVENTS = [
    ("response.output_item.added",
     {"type": "response.output_item.added", "output_index": 1,
      "item": {"id": "fc_1", "type": "function_call", "call_id": "call_1",
               "name": "get_weather", "arguments": ""}}),
    ("response.function_call_arguments.delta",
     {"type": "response.function_call_arguments.delta", "output_index": 1,
      "delta": "{\"city\":"}),
    ("response.function_call_arguments.delta",
     {"type": "response.function_call_arguments.delta", "output_index": 1,
      "delta": "\"北京\"}"}),
    ("response.output_item.done",
     {"type": "response.output_item.done", "output_index": 1,
      "item": {"id": "fc_1", "type": "function_call", "call_id": "call_1",
               "name": "get_weather", "arguments": "{\"city\":\"北京\"}"}}),
]

COMPLETED = ("response.completed", {
    "type": "response.completed",
    "response": {
        "id": "resp_1", "object": "response", "model": "gpt-5.6-sol",
        "status": "completed",
        "usage": {"input_tokens": 9, "output_tokens": 5, "total_tokens": 14,
                  "input_tokens_details": {"cached_tokens": 0},
                  "output_tokens_details": {"reasoning_tokens": 2}},
    },
})

FAILED = ("response.failed", {
    "type": "response.failed",
    "response": {"id": "resp_2", "status": "failed",
                 "error": {"message": "上游自己炸了"}},
})


def sse_body(events):
    out = []
    for name, payload in events:
        out.append("event: " + name + "\n")
        out.append("data: " + json.dumps(payload, ensure_ascii=False) + "\n\n")
    return "".join(out).encode("utf-8")


class Upstream(object):
    def __init__(self):
        self.mode = "text"          # text | tool | failed | http_error
        self.seen_headers = []
        self.seen_bodies = []


STATE = Upstream()


class FakeAir(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def _json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        STATE.seen_headers.append(dict(self.headers))
        if self.path == "/v1/models":
            return self._json(200, {"object": "list", "data": [
                {"id": "gpt-5.6-sol", "object": "model"},
                {"id": "gpt-6-astra", "object": "model"},
            ]})
        return self._json(404, {"error": {"message": "no such path"}})

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        STATE.seen_headers.append(dict(self.headers))
        try:
            STATE.seen_bodies.append(json.loads(raw.decode("utf-8")))
        except Exception:
            STATE.seen_bodies.append({})
        if self.path != "/v1/responses":
            return self._json(404, {"error": {"message": "no such path"}})
        if STATE.mode == "http_error":
            return self._json(400, {"error": {"message":
                "模型 gpt-5.6-sol 不支持本接口"}})
        if STATE.mode == "failed":
            events = [FAILED]
        elif STATE.mode == "tool":
            events = TOOL_EVENTS + [COMPLETED]
        else:
            events = TEXT_EVENTS + [COMPLETED]
        body = sse_body(events)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
        self.close_connection = True


srv = ThreadingHTTPServer(("127.0.0.1", 0), FakeAir)
threading.Thread(target=srv.serve_forever, daemon=True).start()
UPSTREAM = "http://127.0.0.1:%d" % srv.server_address[1]

HUB_KEY = "hub-key-air-0001"


class FakePool(object):
    """Air 出口不该碰 WorkBuddy 账号池；碰了就让用例炸掉。"""

    def __getattr__(self, name):
        raise AssertionError("WorkBuddy pool used: %s" % name)


hub = wb_proxy.GatewayServer(("127.0.0.1", 0), wb_proxy.Handler)
threading.Thread(target=hub.serve_forever, daemon=True).start()
HUB = "http://127.0.0.1:%d" % hub.server_address[1]


def post(path, payload, key=None):
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = "Bearer " + key
    req = urllib.request.Request(HUB + path, data=json.dumps(payload).encode("utf-8"),
                                 headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")


def get(path, key=None):
    headers = {}
    if key:
        headers["Authorization"] = "Bearer " + key
    req = urllib.request.Request(HUB + path, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")


def data_objects(raw):
    out = []
    for line in raw.splitlines():
        if not line.startswith("data: "):
            continue
        payload = line[6:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            out.append(json.loads(payload))
        except Exception:
            pass
    return out


def stream_text(raw):
    return "".join(
        (obj.get("choices") or [{}])[0].get("delta", {}).get("content") or ""
        for obj in data_objects(raw))


try:
    wb_proxy.POOL = FakePool()
    wb_proxy.CURRENT_REALM = "intl"

    # ---------------------------------------------------------------- 门禁
    print("== 出口可选性 ==")
    check("未配置时 realm_options 不含 air",
          "air" not in wb_proxy.realm_options(),
          wb_proxy.realm_options())
    check("REALMS 接受 air 作为 Key 的出口",
          "air" in wb_settings.REALMS)

    wb_air.save_config(ACCOUNTS, {"enabled": False, "base_url": UPSTREAM,
                                  "api_key": "sk-test-air"})
    check("开关关着时仍不算已配置",
          wb_air.configured(ACCOUNTS) is False)
    check("开关关着时 realm_options 仍不含 air",
          "air" not in wb_proxy.realm_options())

    wb_air.save_config(ACCOUNTS, {"enabled": True})
    check("开关与 Key 都齐了才算已配置", wb_air.configured(ACCOUNTS) is True)
    check("配置完成后 realm_options 含 air",
          "air" in wb_proxy.realm_options(), wb_proxy.realm_options())
    masked = wb_air.masked_config(ACCOUNTS)
    check("面板快照不回明文 Key",
          "sk-test-air" not in json.dumps(masked, ensure_ascii=False)
          and masked.get("api_key_masked", "").endswith("air"),
          masked)

    wb_settings.set_api_keys(ACCOUNTS, [{
        "key": HUB_KEY, "name": "air-test", "realm": "air", "enabled": True,
    }])

    # ------------------------------------------------------- 请求体翻译
    print("== Chat -> Responses 请求体 ==")
    body = wb_air.build_chat_body({
        "model": "gpt-5.6-sol",
        "max_tokens": 256,
        "messages": [
            {"role": "system", "content": "你是助手"},
            {"role": "user", "content": "北京天气"},
            {"role": "assistant", "content": "", "tool_calls": [{
                "id": "call_1", "type": "function",
                "function": {"name": "get_weather",
                             "arguments": "{\"city\":\"北京\"}"}}]},
            {"role": "tool", "tool_call_id": "call_1", "content": "12度"},
        ],
        "tools": [{"type": "function", "function": {
            "name": "get_weather", "description": "查天气",
            "parameters": {"type": "object", "properties": {}}}}],
        "tool_choice": {"type": "function", "function": {"name": "get_weather"}},
    })
    check("system 折进 instructions", body.get("instructions") == "你是助手", body)
    check("max_tokens 映射为 max_output_tokens", body.get("max_output_tokens") == 256)
    check("始终流式且不落上游会话",
          body.get("stream") is True and body.get("store") is False, body)
    kinds = [item.get("type") or item.get("role") for item in body["input"]]
    check("工具调用折成 function_call 项", "function_call" in kinds, kinds)
    check("工具结果折成 function_call_output 项",
          "function_call_output" in kinds, kinds)
    call = [i for i in body["input"] if i.get("type") == "function_call"][0]
    check("function_call 带 call_id 与名字",
          call.get("call_id") == "call_1" and call.get("name") == "get_weather", call)
    out = [i for i in body["input"] if i.get("type") == "function_call_output"][0]
    check("function_call_output 带 call_id 与结果",
          out.get("call_id") == "call_1" and out.get("output") == "12度", out)
    check("工具定义摊平成 Responses 形式",
          body["tools"] == [{"type": "function", "name": "get_weather",
                             "description": "查天气",
                             "parameters": {"type": "object", "properties": {}}}],
          body.get("tools"))
    check("tool_choice 折成 {\"type\": \"function\", \"name\": ...}",
          body.get("tool_choice") == {"type": "function", "name": "get_weather"},
          body.get("tool_choice"))

    # ----------------------------------------------------------- 文本流
    print("== 文本流翻译 ==")
    STATE.mode = "text"
    STATE.seen_headers = []
    STATE.seen_bodies = []
    status, raw = post("/v1/chat/completions", {
        "model": "gpt-5.6-sol", "stream": True,
        "messages": [{"role": "user", "content": "打个招呼"}],
    }, HUB_KEY)
    check("流式 chat 返回 200", status == 200, raw[:200])
    check("文本分片按序拼成整句", stream_text(raw) == "你好！", stream_text(raw))
    objs = data_objects(raw)
    finishes = [c.get("finish_reason") for o in objs for c in (o.get("choices") or [])]
    check("终止帧为 stop", "stop" in finishes, finishes)
    usage_frames = [o.get("usage") for o in objs if o.get("usage")]
    check("回程带 usage 帧", bool(usage_frames), objs[-1] if objs else None)
    if usage_frames:
        check("usage 换算成 prompt/completion",
              usage_frames[-1].get("prompt_tokens") == 9
              and usage_frames[-1].get("completion_tokens") == 5,
              usage_frames[-1])
        check("推理 token 进 completion_tokens_details",
              (usage_frames[-1].get("completion_tokens_details") or {})
              .get("reasoning_tokens") == 2, usage_frames[-1])
    check("上游收到配置的 User-Agent",
          any(h.get("User-Agent") == wb_air.DEFAULT_USER_AGENT
              for h in STATE.seen_headers),
          [h.get("User-Agent") for h in STATE.seen_headers])
    check("上游收到 Bearer 密钥",
          any(h.get("Authorization") == "Bearer sk-test-air"
              for h in STATE.seen_headers),
          [h.get("Authorization") for h in STATE.seen_headers])
    check("上游收到的模型名与网关一致",
          (STATE.seen_bodies or [{}])[-1].get("model") == "gpt-5.6-sol",
          (STATE.seen_bodies or [{}])[-1].get("model"))

    print("== 非流式聚合 ==")
    status, raw = post("/v1/chat/completions", {
        "model": "gpt-5.6-sol", "stream": False,
        "messages": [{"role": "user", "content": "打个招呼"}],
    }, HUB_KEY)
    parsed = json.loads(raw) if status == 200 else {}
    content = ((parsed.get("choices") or [{}])[0].get("message") or {}).get("content")
    check("非流式 chat 返回 200", status == 200, raw[:200])
    check("非流式正文由事件流折叠而来", content == "你好！", content)

    # ----------------------------------------------------------- 工具流
    print("== 工具调用流 ==")
    STATE.mode = "tool"
    status, raw = post("/v1/chat/completions", {
        "model": "gpt-5.6-sol", "stream": True,
        "messages": [{"role": "user", "content": "查天气"}],
        "tools": [{"type": "function", "function": {
            "name": "get_weather", "parameters": {"type": "object"}}}],
    }, HUB_KEY)
    calls = []
    for obj in data_objects(raw):
        for choice in obj.get("choices") or []:
            calls.extend((choice.get("delta") or {}).get("tool_calls") or [])
    check("流式工具调用返回 200", status == 200, raw[:200])
    check("回程出现 tool_calls", bool(calls), calls[:2])
    if calls:
        name = "".join((c.get("function") or {}).get("name") or "" for c in calls)
        args = "".join((c.get("function") or {}).get("arguments") or "" for c in calls)
        check("工具名回传正确", name == "get_weather", name)
        check("参数增量拼成完整 JSON", args == "{\"city\":\"北京\"}", args)
        check("首帧带 call id", calls[0].get("id") == "call_1", calls[0])
    finishes = [c.get("finish_reason") for o in data_objects(raw)
                for c in (o.get("choices") or [])]
    check("终止帧为 tool_calls", "tool_calls" in finishes, finishes)

    # ------------------------------------------------------------- 报错
    print("== 错误映射 ==")
    STATE.mode = "http_error"
    status, raw = post("/v1/chat/completions", {
        "model": "gpt-5.6-sol", "stream": True,
        "messages": [{"role": "user", "content": "hi"}],
    }, HUB_KEY)
    check("上游 400 原样映射成 400", status == 400, raw[:200])
    check("错误正文带上游解释", "不支持" in raw, raw[:200])

    STATE.mode = "failed"
    status, raw = post("/v1/chat/completions", {
        "model": "gpt-5.6-sol", "stream": True,
        "messages": [{"role": "user", "content": "hi"}],
    }, HUB_KEY)
    check("流内 failed 事件被译成错误帧或错误响应",
          status == 400 or "上游自己炸了" in raw or "aborted" in raw,
          (status, raw[:200]))

    # -------------------------------------------------------- 模型目录
    print("== /v1/models ==")
    STATE.mode = "text"
    status, raw = get("/v1/models", HUB_KEY)
    parsed = json.loads(raw) if status == 200 else {}
    ids = [m.get("id") for m in parsed.get("data") or []]
    check("realm=air 时 /v1/models 返回 200", status == 200, raw[:200])
    check("模型目录来自上游", "gpt-5.6-sol" in ids, ids)
    check("响应标注 realm", parsed.get("realm") == "air", parsed.get("realm"))

    # ------------------------------------------------------------ 用量
    print("== 用量归属 ==")
    rows = []
    usage_file = os.path.join(USAGE, "usage.jsonl")
    if os.path.isfile(usage_file):
        with open(usage_file, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception:
                    pass
    air_rows = [r for r in rows if r.get("realm") == "air"]
    check("成功请求落了一条 realm=air 的用量行", bool(air_rows),
          [r.get("realm") for r in rows][:5])
    if air_rows:
        check("用量行记了模型名",
              any(r.get("model") == "gpt-5.6-sol" for r in air_rows),
              [r.get("model") for r in air_rows][:3])
        check("模型不在价格表里时标 unpriced",
              any(str(r.get("cost_policy") or "").startswith("air:")
                  for r in air_rows),
              [r.get("cost_policy") for r in air_rows][:3])

finally:
    try:
        hub.shutdown()
    except Exception:
        pass
    try:
        srv.shutdown()
    except Exception:
        pass

print("")
print("PASS %d  FAIL %d" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
